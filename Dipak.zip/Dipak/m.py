#!/usr/bin/python3
# By @jodsmoker - 2026 Pro Bot (Safe Version)

import telebot
from telebot.types import ReplyKeyboardMarkup, KeyboardButton
import datetime
import time
import threading

TOKEN = "8216732171:AAHjZXkLQFbhgoHlRPqygsBNklGgttIK2u8"
bot = telebot.TeleBot(TOKEN)

admin_id = ["8427123089"]

# -------- USER SYSTEM --------
users = {}
MAX_SLOTS = 5
active_tasks = 0

# -------- START MENU --------
@bot.message_handler(commands=['start'])
def start(msg):
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add(
        KeyboardButton("Instant Plan 🧡"),
        KeyboardButton("Instant++ Plan 💥")
    )
    markup.add(
        KeyboardButton("My Account🏦"),
        KeyboardButton("Status 📊")
    )
    markup.add(
        KeyboardButton("Help❓"),
        KeyboardButton("Contact Admin☎️")
    )

    bot.send_message(msg.chat.id, "✨ Welcome to @jodsmoker Control Panel\nChoose option:", reply_markup=markup)

# -------- STATUS --------
@bot.message_handler(commands=['status'])
def status(msg):
    bot.reply_to(msg, f"""
📊 BOT STATUS

🟢 Slots: {active_tasks}/{MAX_SLOTS}
🟢 Free: {MAX_SLOTS - active_tasks}
🟢 Time: {datetime.datetime.now().strftime('%H:%M:%S')}

System Stable ✅
""")

# -------- ACCOUNT --------
@bot.message_handler(func=lambda m: m.text == "My Account🏦")
def account(msg):
    uid = msg.from_user.id
    plan = users.get(uid, {}).get("plan", "FREE")
    valid = users.get(uid, {}).get("valid", "N/A")

    bot.reply_to(msg, f"""
👤 ACCOUNT INFO

ID: {uid}
Plan: {plan}
Valid: {valid}
Bot: @jodsmoker
""")

# -------- APPROVE --------
@bot.message_handler(commands=['approve'])
def approve(msg):
    if str(msg.chat.id) not in admin_id:
        bot.reply_to(msg, "🚫 Admin only")
        return

    try:
        _, uid, plan, days = msg.text.split()
        uid = int(uid)
        valid = (datetime.datetime.now() + datetime.timedelta(days=int(days))).date()

        users[uid] = {
            "plan": plan,
            "valid": str(valid)
        }

        bot.reply_to(msg, f"✅ User {uid} approved ({plan}) till {valid}")
    except:
        bot.reply_to(msg, "Usage: /approve <id> <plan> <days>")

# -------- TASK SYSTEM --------
def end_task():
    global active_tasks
    time.sleep(300)  # 5 minutes
    active_tasks -= 1

@bot.message_handler(commands=['task'])
def task(msg):
    global active_tasks
    uid = msg.from_user.id

    if uid not in users:
        bot.reply_to(msg, "🚫 Not Approved")
        return

    if active_tasks >= MAX_SLOTS:
        bot.reply_to(msg, "⚠️ All slots busy")
        return

    active_tasks += 1

    bot.reply_to(msg, f"""
🚀 TASK STARTED

Time: 300s (5 min)
Slots: {active_tasks}/{MAX_SLOTS}

Status: Running...
""")

    threading.Thread(target=end_task).start()

# -------- BUTTON HANDLER --------
@bot.message_handler(func=lambda m: True)
def buttons(msg):
    if msg.text == "Instant Plan 🧡":
        bot.reply_to(msg, "🧡 Instant Plan Activated\nUse /task")
    elif msg.text == "Instant++ Plan 💥":
        bot.reply_to(msg, "💥 Instant++ Plan Activated\nUse /task")
    elif msg.text == "Status 📊":
        status(msg)
    elif msg.text == "Help❓":
        bot.reply_to(msg, """
📜 COMMANDS

/task - Start task
/status - Bot status
/approve - Admin only
""")
    elif msg.text == "Contact Admin☎️":
        bot.reply_to(msg, "📞 Contact: @jodsmoker")
    else:
        bot.reply_to(msg, "❌ Invalid option")

# -------- RUN --------
print("Bot running...")
bot.infinity_polling()