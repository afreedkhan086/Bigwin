#!/usr/bin/python3
# By @jodsmoker - 2026 Safe Control Bot

import telebot
import datetime
import os
import threading
import time

bot = telebot.TeleBot("8216732171:AAHjZXkLQFbhgoHlRPqygsBNklGgttIK2u8")

admin_id = ["8427123089"]

USER_FILE = "users.txt"
LOG_FILE = "log.txt"

MAX_SLOTS = 5
active_tasks = 0
user_last_used = {}

# ------------------ FILE HANDLING ------------------

def read_users():
    try:
        with open(USER_FILE, "r") as f:
            return f.read().splitlines()
    except:
        return []

def save_user(user_id):
    with open(USER_FILE, "a") as f:
        f.write(user_id + "\n")

allowed_users = read_users()

# ------------------ LOGGING ------------------

def log(user_id, command):
    with open(LOG_FILE, "a") as f:
        f.write(f"{datetime.datetime.now()} | {user_id} | {command}\n")

# ------------------ ADMIN ------------------

@bot.message_handler(commands=['add'])
def add_user(msg):
    if str(msg.chat.id) in admin_id:
        try:
            uid = msg.text.split()[1]
            if uid not in allowed_users:
                allowed_users.append(uid)
                save_user(uid)
                bot.reply_to(msg, f"✅ User {uid} added")
            else:
                bot.reply_to(msg, "⚠️ Already exists")
        except:
            bot.reply_to(msg, "Usage: /add <id>")
    else:
        bot.reply_to(msg, "🚫 Admin only")

@bot.message_handler(commands=['remove'])
def remove_user(msg):
    if str(msg.chat.id) in admin_id:
        try:
            uid = msg.text.split()[1]
            if uid in allowed_users:
                allowed_users.remove(uid)
                with open(USER_FILE, "w") as f:
                    for u in allowed_users:
                        f.write(u + "\n")
                bot.reply_to(msg, f"❌ Removed {uid}")
            else:
                bot.reply_to(msg, "User not found")
        except:
            bot.reply_to(msg, "Usage: /remove <id>")
    else:
        bot.reply_to(msg, "🚫 Admin only")

# ------------------ STATUS ------------------

@bot.message_handler(commands=['status'])
def status(msg):
    global active_tasks
    bot.reply_to(msg, f"""
🤖 @jodsmoker SYSTEM STATUS

🟢 Active Slots: {active_tasks}/{MAX_SLOTS}
🟢 Free Slots: {MAX_SLOTS - active_tasks}
👥 Users: {len(allowed_users)}

System Stable ✅ (2026 Core)
""")

# ------------------ USER INFO ------------------

@bot.message_handler(commands=['myinfo'])
def myinfo(msg):
    uid = str(msg.chat.id)
    bot.reply_to(msg, f"""
👤 USER PANEL

ID: {uid}
Access: {"✅ Approved" if uid in allowed_users else "❌ Not Approved"}
Bot: @jodsmoker
""")

# ------------------ COOLDOWN ------------------

@bot.message_handler(commands=['when'])
def when(msg):
    uid = str(msg.chat.id)
    if uid in user_last_used:
        remaining = 60 - (datetime.datetime.now() - user_last_used[uid]).seconds
        if remaining > 0:
            bot.reply_to(msg, f"⏳ Wait {remaining}s")
            return
    bot.reply_to(msg, "✅ Ready")

# ------------------ TASK SYSTEM ------------------

@bot.message_handler(commands=['start'])
def start(msg):
    bot.reply_to(msg, f"""
Welcome {msg.from_user.first_name} 👋

Use /help to explore.

Bot by @jodsmoker 🚀
""")

@bot.message_handler(commands=['help'])
def help_cmd(msg):
    bot.reply_to(msg, """
📜 COMMANDS

/starttask - Start task
/status - Bot status
/myinfo - Your info
/when - Cooldown
/help - Help menu
""")

@bot.message_handler(commands=['starttask'])
def start_task(msg):
    global active_tasks
    uid = str(msg.chat.id)

    if uid not in allowed_users:
        bot.reply_to(msg, "🚫 Not approved. Contact owner.")
        return

    if active_tasks >= MAX_SLOTS:
        bot.reply_to(msg, "⚠️ Slots full")
        return

    if uid in user_last_used:
        if (datetime.datetime.now() - user_last_used[uid]).seconds < 60:
            bot.reply_to(msg, "⏳ Cooldown active")
            return

    active_tasks += 1
    user_last_used[uid] = datetime.datetime.now()

    bot.reply_to(msg, "🚀 Task Started")

    log(uid, "starttask")

    def end_task():
        global active_tasks
        time.sleep(30)
        active_tasks -= 1

    threading.Thread(target=end_task).start()

# ------------------ BROADCAST ------------------

@bot.message_handler(commands=['broadcast'])
def broadcast(msg):
    if str(msg.chat.id) in admin_id:
        try:
            text = msg.text.split(" ", 1)[1]
            for u in allowed_users:
                try:
                    bot.send_message(u, f"📢 {text}")
                except:
                    pass
            bot.reply_to(msg, "✅ Broadcast sent")
        except:
            bot.reply_to(msg, "Usage: /broadcast <msg>")
    else:
        bot.reply_to(msg, "🚫 Admin only")

# ------------------ RUN ------------------

print("Bot running...")
bot.infinity_polling()