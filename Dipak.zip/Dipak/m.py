#!/usr/bin/python3
# By @jodsmoker - 2026 Safe Task Bot (No Slots)

import telebot
from telebot.types import ReplyKeyboardMarkup, KeyboardButton
from datetime import datetime, timedelta
import threading
import time

TOKEN = "8216732171:AAHjZXkLQFbhgoHlRPqygsBNklGgttIK2u8"
bot = telebot.TeleBot(TOKEN)

# Admin
admin_id = ["8427123089"]

# Users
users = {}  # {user_id: {"plan": "Instant", "valid": date}}

# ---------------- START MENU ----------------
@bot.message_handler(commands=['start'])
def start(msg):
    markup = ReplyKeyboardMarkup(resize_keyboard=True)
    markup.add(
        KeyboardButton("Instant Plan 🧡"),
        KeyboardButton("Instant++ Plan 💥")
    )
    markup.add(
        KeyboardButton("My Account🏦"),
        KeyboardButton("Status 📊")
    )
    markup.add(
        KeyboardButton("Help❓"),
        KeyboardButton("Contact Admin☎️")
    )
    bot.send_message(msg.chat.id, "✨ Welcome to @jodsmoker Control Panel\nChoose option:", reply_markup=markup)

# ---------------- STATUS ----------------
@bot.message_handler(commands=['status'])
def status(msg):
    bot.reply_to(msg, f"""
📊 BOT STATUS

🟢 Time: {datetime.now().strftime('%H:%M:%S')}
System Stable ✅
""")

# ---------------- ACCOUNT ----------------
@bot.message_handler(func=lambda m: m.text == "My Account🏦")
def account(msg):
    uid = msg.from_user.id
    plan = users.get(uid, {}).get("plan", "FREE")
    valid = users.get(uid, {}).get("valid", "N/A")
    bot.reply_to(msg, f"""
👤 ACCOUNT INFO

ID: {uid}
Plan: {plan}
Valid: {valid}
Bot: @jodsmoker
""")

# ---------------- APPROVE ----------------
@bot.message_handler(commands=['approve'])
def approve(msg):
    if str(msg.chat.id) not in admin_id:
        bot.reply_to(msg, "🚫 Admin only")
        return
    try:
        _, uid, plan, days = msg.text.split()
        uid = int(uid)
        valid = (datetime.now() + timedelta(days=int(days))).date()
        users[uid] = {"plan": plan, "valid": str(valid)}
        bot.reply_to(msg, f"✅ User {uid} approved ({plan}) till {valid}")
    except:
        bot.reply_to(msg, "Usage: /approve <id> <plan> <days>")

# ---------------- TASK SYSTEM ----------------
def run_task(message, target_ip, target_port, duration):
    username = message.from_user.username or "unknown"
    start_time = datetime.now()
    end_time = start_time + timedelta(seconds=duration)

    # START MESSAGE
    start_msg = f"""
✅ TASK LAUNCHED!

User: @{username}
Target: {target_ip}:{target_port}
Duration: {duration}s
Server: #1
Started: {start_time.strftime('%H:%M:%S')} IST
Ends: {end_time.strftime('%H:%M:%S')} IST

Status: Running... 🚀
"""
    bot.send_message(message.chat.id, start_msg)

    def finish_task():
        time.sleep(duration)
        complete_time = datetime.now()
        # COMPLETED MESSAGE
        end_msg = f"""
✅ TASK COMPLETED

User: @{username}
Target: {target_ip}:{target_port}
Duration: {duration}s
Server: #1
Completed: {complete_time.strftime('%H:%M:%S')} IST
"""
        bot.send_message(message.chat.id, end_msg)

    threading.Thread(target=finish_task).start()

# ---------------- BUTTON HANDLER ----------------
@bot.message_handler(func=lambda m: True)
def buttons(msg):
    if msg.text == "Instant Plan 🧡":
        bot.reply_to(msg, "🧡 Instant Plan Activated\nUse /task <IP> <PORT> <DURATION>")
    elif msg.text == "Instant++ Plan 💥":
        bot.reply_to(msg, "💥 Instant++ Plan Activated\nUse /task <IP> <PORT> <DURATION>")
    elif msg.text == "Status 📊":
        status(msg)
    elif msg.text == "Help❓":
        bot.reply_to(msg, """
📜 COMMANDS

/task <IP> <PORT> <DURATION> - Start task
/status - Show bot status
/approve - Admin only
""")
    elif msg.text == "Contact Admin☎️":
        bot.reply_to(msg, "📞 Contact: @jodsmoker")
    elif msg.text.startswith("/task"):
        try:
            parts = msg.text.split()
            target_ip, target_port, duration = parts[1], int(parts[2]), int(parts[3])
            run_task(msg, target_ip, target_port, duration)
        except:
            bot.reply_to(msg, "Usage: /task <IP> <PORT> <DURATION>")
    else:
        bot.reply_to(msg, "❌ Invalid option")

# ---------------- RUN BOT ----------------
print("GOP GOP GOP")
bot.infinity_polling()